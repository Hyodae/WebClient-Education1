/*
    Arrow function을 작성하고, babel로 ES5 코드로 transpile 하라
*/
const sum = (val1, val2) => val1 + val2;

console.log(sum(5, 5));
