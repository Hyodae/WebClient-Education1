ECMAScript
환경구성: Polyfill, Babel, Webpack
변수: let, const
Function - 디폴트 파라미터
Arrow function
Object 표현식
Destructuring
Rest parameter / Spread operator
Template Literals / Tagged Template
Class
Modules
Promise
Async/Await
Fetch API
