/*
     @TODO webpack config 설정을 작성하세요.
     1) 기본 webpack 설정
     - entry는 index.js
     - output은 dist 폴더에 webapp.bundle.js 파일로 출력하라.

     2) babel-loader를 설정

     3) webpack-dev-server를 설정

     4) 개발/배포 버전 번들링 설정 (package.json에 명령어 추가)
*/