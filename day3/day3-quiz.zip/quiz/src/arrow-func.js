/*
    Arrow function을 작성하고, babel로 ES5 코드로 transpile 하라
*/