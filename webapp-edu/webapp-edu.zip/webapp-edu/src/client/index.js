import MovieManager from './MovieManager';


new MovieManager();